package com.example.presentgeo.model;

public class JsonUser {
    private Boolean code;
    private String message;
    private User data;

    public Boolean getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public User getUser() {
        return data;
    }
}
