package com.example.presentgeo.model;

public class PolygonMarker {
    private String id_map;
    private String id_maps;
    private String lat;
    private String lng;

    public String getId_map() {
        return id_map;
    }

    public String getId_maps() {
        return id_maps;
    }

    public String getLat() {
        return lat;
    }

    public String getLng() {
        return lng;
    }
}
