package com.example.presentgeo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.RelativeSizeSpan;

import com.google.android.material.textview.MaterialTextView;

public class LandingAbsenPegawaiActivity extends AppCompatActivity {

    MaterialTextView eDate,eInstansi,eTahun,eNip;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing_absen_pegawai);
        Toolbar myToolbar = findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);


        eDate = findViewById(R.id.tvDate);
        eInstansi = findViewById(R.id.tvInstansiLn);
        eTahun = findViewById(R.id.tvTahun);
        eNip = findViewById(R.id.tvNip);

        //buat huruf awal jadi besar
        String dateCombination = eDate.getText().toString();
        SpannableString ssDate = new SpannableString(dateCombination);
        ssDate.setSpan( new RelativeSizeSpan(2f),0,1,0);
        eDate.setText(ssDate);



    }
}