package com.example.presentgeo.model;

public class JsonRespon {
private Boolean code;
private int inarea;
private String message;

    public Boolean getCode() {
        return code;
    }

    public int getInarea() {
        return inarea;
    }

    public String getMessage() {
        return message;
    }
}
